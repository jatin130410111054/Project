package com.capgemini.hbms.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="bookingdetails")
public class BookingDetailsBean {
	
	@Id
	@SequenceGenerator(name="bookingSeq",sequenceName="booking_id_sequence",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="bookingSeq")
	@Column(name="booking_id",length=10)
	private String bookingId;
	
	@Column(name="room_id",length=10)
	private String roomId;
	
	@Column(name="user_id",length=10)
	private String userId;
	
	@Column(name="booked_from")
	@Temporal(TemporalType.DATE)
	private LocalDate bookedFrom;
	
	@Column(name="booked_to")
	@Temporal(TemporalType.DATE)
	private LocalDate bookedTo;
	
	@Column(name="no_of_adults")
	private int noOfAdults;
	
	@Column(name="no_of_children")
	private int noOfChildren;
	
	@Column(name="amount")
	private double amount;

	
	public BookingDetailsBean() {
		super();
	}

	
	public BookingDetailsBean(String bookingId, String roomId, String userId,
			LocalDate bookedFrom, LocalDate bookedTo, int noOfAdults,
			int noOfChildren, double amount) {
		super();
		this.bookingId = bookingId;
		this.roomId = roomId;
		this.userId = userId;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}


	public BookingDetailsBean(String roomId, String userId, LocalDate bookedFrom, LocalDate bookedTo,
			int noOfAdults, int noOfChildren, double amount) {
		super();
		
		this.roomId = roomId;
		this.userId = userId;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public LocalDate getBookedFrom() {
		return bookedFrom;
	}

	public void setBookedFrom(LocalDate bookedFrom) {
		this.bookedFrom = bookedFrom;
	}

	public LocalDate getBookedTo() {
		return bookedTo;
	}

	public void setBookedTo(LocalDate bookedTo) {
		this.bookedTo = bookedTo;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "BookingDetailsBean [bookingId=" + bookingId + ", roomId=" + roomId + ", userId=" + userId
				+ ", bookedFrom=" + bookedFrom + ", bookedTo=" + bookedTo + ", noOfAdults=" + noOfAdults
				+ ", noOfChildren=" + noOfChildren + ", amount=" + amount + "]";
	}

}