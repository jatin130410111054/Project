package com.capgemini.hbms.bean;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="roomdetails")
public class RoomDetailsBean {
	
	@Column(name="hotel_id",length=10)
	private String hotelId;
	
	@Column(name="room_id",length=10)
	private String roomId;
	
	@Column(name="room_no",length=5)
	private String roomNo;
	
	@Column(name="room_type",length=20)
	private String roomType;
	
	@Column(name="per_night_rate",precision=10,scale=2)
	private double perNightRate;
	
	@Column(name="availability",length=3)
	private String availability;
	
	@Column(name="photo")
	private Blob photo;
	
	
	public RoomDetailsBean() {
		super();
	}

	public RoomDetailsBean(String hotelId, String roomId, String roomNo,
			String roomType, double perNightRate, String availability,
			Blob photo) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.perNightRate = perNightRate;
		this.availability = availability;
		this.photo = photo;
	}	
	
	public RoomDetailsBean(String hotelId, String roomId) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
	}
	

	public String getHotelId() {
		return hotelId;
	}

	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public double getPerNightRate() {
		return perNightRate;
	}

	public void setPerNightRate(double perNightRate) {
		this.perNightRate = perNightRate;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public Blob getPhoto() {
		return photo;
	}

	public void setPhoto(Blob photo) {
		this.photo = photo;
	}

}
