package com.capgemini.hbms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class UserDetailsBean {
	
	@Id
	@SequenceGenerator(name="userSeq",sequenceName="user_id_sequence",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="userSeq")
	@Column(name = "user_id",length=10)
	private String userId;
	
	@Column(name = "password",length=20)
	private String password;
	
	@Column(name = "role",length=10)
	private String role;
	
	@Column(name = "user_name",length=30)
	private String userName;
	
	@Column(name = "mobile_no",length=10)
	private String mobileNo;
	
	@Column(name = "phone",length=10)
	private String phone;
	
	@Column(name = "address",length=70)
	private String address;
	
	@Column(name = "email",length=40)
	private String email;
	
	public UserDetailsBean() {
		super();
	}
	
	
	public UserDetailsBean(String userName,String password, String role,
			String mobile_no, String phone, String address,
			String email) {
		super();
		this.password = password;
		this.role = role;
		this.userName = userName;
		this.mobileNo = mobile_no;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}


	
	
	public UserDetailsBean(String userId, String password, String role, String userName, String mobileNo, String phone,
			String address, String email) {
		super();
		this.userId = userId;
		this.password = password;
		this.role = role;
		this.userName = userName;
		this.mobileNo = mobileNo;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}


	public String getUserId() {
		return userId;
	}

	

	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public UserDetailsBean(String userId, String password, String role) {
		super();
		this.userId = userId;
		this.password = password;
		this.role = role;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getMobile_no() {
		return mobileNo;
	}


	public void setMobile_no(String mobile_no) {
		this.mobileNo = mobile_no;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "UserDetails [userId=" + userId + ", password=" + password
				+ ", role=" + role + ", userName=" + userName + ", mobile_no="
				+ mobileNo + ", phone=" + phone + ", address=" + address
				+ ", email=" + email + "]";
	}
	
	
	
	
	
}