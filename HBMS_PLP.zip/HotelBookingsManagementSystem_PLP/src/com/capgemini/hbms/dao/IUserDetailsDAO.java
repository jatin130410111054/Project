package com.capgemini.hbms.dao;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserDetailsDAO {
	
	String RegisterUser(UserDetailsBean userDetails) 
			throws HBMSException;

}