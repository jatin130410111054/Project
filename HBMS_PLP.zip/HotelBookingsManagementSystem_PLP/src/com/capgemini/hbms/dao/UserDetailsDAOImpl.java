package com.capgemini.hbms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.stereotype.Repository;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

@Repository
@Transactional
public class UserDetailsDAOImpl implements IUserDetailsDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public String RegisterUser(UserDetailsBean userDetails)
			throws HBMSException {
		
		String userId = null;

		PropertyConfigurator.configure("resources/log4j.properties");
		Logger logger = Logger.getRootLogger();
		
		try{
			
			entityManager.persist(userDetails);
			
			Query q = entityManager.createNativeQuery("SELECT user_id_sequence.NEXTVAL FROM DUAL");
			
			userId =(String)q.getSingleResult();  
			
			logger.info("UserDetailsDAO : User registered !!");
			
		} catch(Exception e){
			logger.info("UserDetailsDAO : User cannot be registered\n" + e.getMessage());
			throw new HBMSException(e.getMessage()); //Throws error	
		}
		
	return userId;
		
	}

}
