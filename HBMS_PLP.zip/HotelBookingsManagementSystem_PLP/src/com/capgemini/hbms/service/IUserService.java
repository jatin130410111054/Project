package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserService {

	String RegisterUser(UserDetailsBean userDetails) throws HBMSException;

}
