package com.capgemini.hbms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.dao.IUserDetailsDAO;
import com.capgemini.hbms.exception.HBMSException;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	IUserDetailsDAO userDetailsDao;
	
	
	@Override
	public String RegisterUser(UserDetailsBean userDetails)
			throws HBMSException {
		
		return userDetailsDao.RegisterUser(userDetails);
	}
}
