package com.cg;

public class Employee {

	int id; 		/*Instance variable has the scope for 
					the entire class...and has default value...here for int it is 0*/
	String name;
	
	static int pf; //Static

	
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	//If parameterised Constructor is made then default constructor is a must
	public Employee() {
		super();
	}





	//Static block
	static{
		System.out.println("Employee Static\n");
	}
}
