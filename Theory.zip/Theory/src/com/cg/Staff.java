package com.cg;

public class Staff {

public static void main(String[] args) {

	int a=10;
	
	if((a==9)|(a++>9)){
		System.out.println("true " + a);
	}else{
		System.out.println("false " + a);
	}
	
	System.out.println("a " + a++ + " " + a);
	
/*===============================================================================	*/
	Employee emp = new Employee();
	
	/*emp.pf = 10;*/
	
	/*OR*/
	
	Employee.pf=10; //Without creating object we can set the static variable by just class name
	//This is the right way
	
	
	Employee emp2 = new Employee();
	
	emp2.pf = 20; //This is not the right way as pf contains yellow mark below
	
	System.out.println("id " + emp2.id);
	System.out.println("pf " + emp2.pf);
	System.out.println("pf " + Employee.pf);
	
	
	
	int b; //Local varaible should always be initialised
}
}
