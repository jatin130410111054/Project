package com.cg;

public class Test {

	int a;
	static int b;
	public static void main(String[] args) {
		
		int c = 0; //Local static as such the main() method is static
		//Local variable should be initialized
		//Scope of c is only inside main()
		
		System.out.println(a);  //We cannot use instance non static variable here
		System.out.println(b);
		System.out.println(c);
		
		Test test;
		test.check(); //Non Static methods can only be called by objects
		
		check2(); //Static methods can directly be called
	}

	public void check(){
		
		System.out.println(c); //c has only scope under main(0
		System.out.println(a);
		
		check2();
	}
	
	public static void check2(){
		
		System.out.println(c);
		System.out.println(a);
		System.out.println(b);

	}
	
}
