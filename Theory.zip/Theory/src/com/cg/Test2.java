package com.cg;

public class Test2 {

	public static void main(String[] args) {
		
		int a= 0;
		System.out.println(a);

		Employee emp = new Employee(); //Mentioned a static block in Employee Class
		
	}
	
	
	//This is Static class
	
	//Static is executed before main()
	static{
		System.out.println("Hii Static1\n\n");
	}

	static{
		System.out.println("Hii Static2\n\n");
	}
}
