package com.cg;

public class Test3 {

	public static void main(String[] args) {
		
		Employee emp = new Employee(10,"Abcd");
		
		Employee emp1 = new Employee();/* If parameterised constructor is present in 
											Employee class then we need to manually make
											default constructor*/
	}
}
