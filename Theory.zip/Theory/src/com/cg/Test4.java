package com.cg;

public class Test4 {

	public static void main(String[] args) {
		
		String str = "CAPGEMINI";
		
		str.replace("I", "U").concat("igate");
		
		System.out.println(str);
		
		str = str.replace("I", "U").concat("igate");
		
		System.out.println(str);
		
		String a = "hello";
		String b = "hello";
		
		System.out.println(a==b);
		
		System.out.println(a.equals(b));

	}
}
