package com.cg;

public class Test5 {

	public static void main(String[] args) {
		
		B b = new B();
		
		B b1 = new B(10);
	}
	
}
	class A{
		
		A(){
			System.out.println("In A..");
		}
		
		A(int a){
			System.out.println("In A.. " + a);
		}
	}
	class B extends A{
		
		B(){
			/*super(); -- default constructor of class A called by compiler at first*/
			System.out.println("In B..");
		}
		
		B(int a){
			/*super(); -- default constructor of class A called by compiler at first*/
			System.out.println("In B.. " + a);
		}
	}
	
