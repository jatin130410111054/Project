package com.cg;

public class Test6 {

	public static void main(String[] args) {
		
		A a = new B(); // run time polymorphism
		a.getData();
	}
}

	class A{
		
		public void getData(){
			System.out.println("In A..");
		}

	}
	
	class B extends A{
		
		public void getData(){
			System.out.println("In B..");
		}
	}
