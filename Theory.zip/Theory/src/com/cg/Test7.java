package com.cg;

import java.util.Comparator;

public class Test7 {

	static boolean b[];
	
	
	public static void main(String[] args) throws Exception {
	
		try{

			int b = 10/0;
		}catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getMessage());
		}finally{
			System.out.println("Always Executed");
		}
		System.out.println("Hello");
		
		System.out.println(b);

		
		boolean c[] = new boolean[3];
		
		
		System.out.println("c1 " + c[0] + " c1 " + c[1]+" c2 " + c[2]);
		
		System.out.println("c3 " + c[3]);
	}
}
