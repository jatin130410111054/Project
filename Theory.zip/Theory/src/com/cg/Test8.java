package com.cg;

import java.util.HashSet;
import java.util.TreeSet;

public class Test8 {

	public static void main(String[] args) {

		HashSet<String> temp = new HashSet();
		
		temp.add("a");
		
		temp.add("J");
		temp.add("L");
		
		temp.add("h");
		temp.add("o");
		temp.add("4");
		
		
		

			System.out.println(temp);

	}
}
