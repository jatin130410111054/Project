package com.cg1;

public class Test6 {

	public static void main(String[] args) {
		
		A a = new B(); // run time polymorphism
		a.getData();
		
		a.getShow();
		
		B b = new B();
		
		b.getShow();
	}
}

	class A{
		
		public void getData(){
			System.out.println("Data In A..");
		}
		
		
	}
	
	class B extends A{
		
		public void getData(){
			System.out.println("Data In B..");
		}
		public void getShow(){
			System.out.println("Show In B..");
		}
	}
